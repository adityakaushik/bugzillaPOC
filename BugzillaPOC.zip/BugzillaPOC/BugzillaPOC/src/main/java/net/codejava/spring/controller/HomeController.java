package net.codejava.spring.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.codejava.spring.dao.*;
import net.codejava.spring.model.*;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * This controller routes accesses to the application to the appropriate
 * hanlder methods. 
 * @author www.codejava.net
 *
 */
@Controller
public class HomeController {

	
	@Autowired
	private AttachmentdataDAO AttachmentdataDAO;
	
	@RequestMapping(value="/")
	public ModelAndView listContact(ModelAndView model) throws IOException{
		//List<Attachmentdata> listAttachmentdata = AttachmentdataDAO.getall();
		List<Attachmentdata> listAttachmentdata =new ArrayList<>();
		model.addObject("listAttachmentdata", listAttachmentdata);
		model.setViewName("home");
		
		return model;
	}
	
	
	@RequestMapping(value = "/getattachment", method = RequestMethod.GET)
	public ModelAndView getattachment(ModelAndView model,HttpServletRequest request) {
		int bug_id = Integer.parseInt(request.getParameter("bug_id"));
		List<Attachmentdata> listAttachmentdata = AttachmentdataDAO.getDatabyId(bug_id);
		model.addObject("listAttachmentdata", listAttachmentdata);
		model.setViewName("home");
		
		return model;
	}
	
	
	@RequestMapping("/retrieve")
	public String download(HttpServletResponse response,HttpServletRequest request) {
		int attach_id = Integer.parseInt(request.getParameter("id"));
	    DownloadFile downloadDocument = AttachmentdataDAO.getFile(attach_id);
	    try {
	        response.setHeader("Content-Disposition", "inline; filename=\"" + attach_id+ "\"");
	        OutputStream out = response.getOutputStream();
	        response.setContentType(downloadDocument.getContentType());
	        IOUtils.copy(downloadDocument.getContent().getBinaryStream(), out);
	        out.flush();
	        out.close();

	    } catch (SQLException e) {
	        System.out.println(e.toString());
	        //Handle exception here
	    } catch (IOException e) {
	        System.out.println(e.toString());
	        //Handle exception here
	    }

	    return "Success";
	}

	
	
	
}
