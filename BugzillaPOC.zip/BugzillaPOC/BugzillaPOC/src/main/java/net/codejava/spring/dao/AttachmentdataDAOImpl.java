package net.codejava.spring.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.mysql.jdbc.Blob;

import net.codejava.spring.model.Attachmentdata;
import net.codejava.spring.model.DownloadFile;

@Component
@Transactional
public class AttachmentdataDAOImpl extends JdbcDaoSupport implements AttachmentdataDAO {

//private JdbcTemplate jdbcTemplate;
	
//	public AttachmentdataDAOImpl(DataSource dataSource) {
//		jdbcTemplate = new JdbcTemplate(dataSource);
//	}
	
	 @Autowired
	 AttachmentdataDAOImpl(DataSource dataSource){
	        setDataSource(dataSource);
	    }
	 
	AttachmentdataDAOImpl() {}
	@Override
	public List<Attachmentdata> getDatabyId(int bug_id) {
		String sql = "select * from attachments inner join attach_data on attachments.attach_id=attach_data.id where bug_id="+bug_id;
		List<Attachmentdata> listAttachmentdata = getJdbcTemplate().query(sql, new RowMapper<Attachmentdata>() {

			@Override
			public Attachmentdata mapRow(ResultSet rs, int rowNum) throws SQLException {
				Attachmentdata attachdata = new Attachmentdata();
	
				attachdata.setAttach_id(rs.getInt("attach_id"));
				attachdata.setAttach_type(rs.getString("mimetype"));
				attachdata.setBug_id(rs.getInt("bug_id"));
				attachdata.setAttach_desc(rs.getString("description"));
				attachdata.setItemImage(rs.getBlob("thedata"));
				return attachdata;
			}
			
		});
		
		return listAttachmentdata;
	}

	
	
	@Override
	public List<Attachmentdata> getall() {
		// TODO Auto-generated method stub
		String sql = "select * from attachments inner join attach_data on attachments.attach_id=attach_data.id LIMIT 3";
		List<Attachmentdata> listAttachmentdata = getJdbcTemplate().query(sql, new RowMapper<Attachmentdata>() {

			@Override
			public Attachmentdata mapRow(ResultSet rs, int rowNum) throws SQLException {
				Attachmentdata attachdata = new Attachmentdata();
	
				attachdata.setAttach_id(rs.getInt("attach_id"));
				attachdata.setAttach_type(rs.getString("mimetype"));
				attachdata.setBug_id(rs.getInt("bug_id"));
				attachdata.setAttach_desc(rs.getString("description"));
				
				attachdata.setItemImage(rs.getBlob("thedata"));
				return attachdata;
			}
			
		});
		
		return listAttachmentdata;
	}

	@Override
	public DownloadFile getFile(int attach_id) {
		// TODO Auto-generated method stub
		
		String sql = "select * from attachments inner join attach_data on attachments.attach_id=attach_data.id where attach_data.id="+attach_id;
		//DownloadFile attachdata = (DownloadFile) getJdbcTemplate().query(sql, new BeanPropertyRowMapper<DownloadFile>());
		List<Attachmentdata> listAttachmentdata = getJdbcTemplate().query(sql, new RowMapper<Attachmentdata>() {
		@Override
		public Attachmentdata mapRow(ResultSet rs, int rowNum) throws SQLException {
			Attachmentdata attachdata = new Attachmentdata();

			attachdata.setAttach_id(rs.getInt("attach_id"));
			attachdata.setAttach_type(rs.getString("mimetype"));
			attachdata.setBug_id(rs.getInt("bug_id"));
			attachdata.setAttach_desc(rs.getString("description"));
			
			attachdata.setItemImage(rs.getBlob("thedata"));
			return attachdata;
		}
		});

		DownloadFile file=new DownloadFile();
		file.setContentType(listAttachmentdata.get(0).getAttach_type());
		file.setContent(listAttachmentdata.get(0).getItemImage());
		return file;
	}

}
