package net.codejava.spring.model;

import java.sql.Blob;

public class Attachmentdata {
  private int bug_id;
  public Blob getItemImage() {
	return itemImage;
}
public void setItemImage(Blob itemImage) {
	this.itemImage = itemImage;
}
private int attach_id;
  private String attach_desc;
  private String attach_type;
  private Blob itemImage;
  
public int getBug_id() {
	return bug_id;
}
public void setBug_id(int bug_id) {
	this.bug_id = bug_id;
}
public int getAttach_id() {
	return attach_id;
}
public void setAttach_id(int attach_id) {
	this.attach_id = attach_id;
}
public String getAttach_desc() {
	return attach_desc;
}
public void setAttach_desc(String attach_desc) {
	this.attach_desc = attach_desc;
}
public String getAttach_type() {
	return attach_type;
}
public void setAttach_type(String attach_type) {
	this.attach_type = attach_type;
}
  
}
