package net.codejava.spring.model;

import java.sql.Blob;

public class DownloadFile {

	String ContentType;
	
	private Blob Content;

	public Blob getContent() {
		return Content;
	}

	public void setContent(Blob content) {
		Content = content;
	}

	public String getContentType() {
		return ContentType;
	}

	public void setContentType(String contentType) {
		ContentType = contentType;
	}

	
	
	
	
}
