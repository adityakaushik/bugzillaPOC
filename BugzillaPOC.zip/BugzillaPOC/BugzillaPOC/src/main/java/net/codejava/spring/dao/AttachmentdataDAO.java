package net.codejava.spring.dao;

import java.util.List;

import org.springframework.stereotype.Service;

import net.codejava.spring.model.Attachmentdata;
import net.codejava.spring.model.DownloadFile;

public interface AttachmentdataDAO {
 
	public  List<Attachmentdata>  getDatabyId(int bug_id);
	
	public DownloadFile getFile(int attach_id);
	
	public List<Attachmentdata> getall();
}
