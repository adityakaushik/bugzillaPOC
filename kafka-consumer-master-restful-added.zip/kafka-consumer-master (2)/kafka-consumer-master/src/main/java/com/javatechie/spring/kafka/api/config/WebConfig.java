package com.javatechie.spring.kafka.api.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.javatechie.spring.repository.DignosticRepo;

@Configuration
@EnableWebMvc
//@ComponentScan(basePackages= {
//		 "com.javatechie.spring",
//"com.javatechie.spring.controller",
//"com.javatechie.spring.repository"}) 
@ComponentScan("com.javatechie.spring")
@EnableJpaRepositories(basePackageClasses = DignosticRepo.class)
@EntityScan("com.javatechie.spring")

public class WebConfig implements WebMvcConfigurer {
     
//    @Override
//    public void configureDefaultServletHandling(
//      DefaultServletHandlerConfigurer configurer) {
//        configurer.enable();
//    }
	
//	
//	@Bean
//    public ViewResolver viewResolver() {
//        InternalResourceViewResolver bean = 
//          new InternalResourceViewResolver();
//        bean.setPrefix("/WEB-INF/");
//        bean.setSuffix(".jsp");
//        return bean;
//    }
}