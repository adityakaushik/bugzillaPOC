package com.javatechie.spring.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;
import com.javatechie.spring.entities.Dignostic;

@Repository
public interface DignosticRepo extends JpaRepository<Dignostic, Long> {
	List<Dignostic> findAll();
	
	Dignostic findById(int id);
	
	@SuppressWarnings("unchecked")
	Dignostic save(Dignostic data);
}
