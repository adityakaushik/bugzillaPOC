package com.javatechie.spring.service;

import java.util.List;

import com.javatechie.spring.entities.Dignostic;


public interface IUIServices {
	public List<Dignostic> getALLDignostics();
	public void addDignostic(Dignostic data);
	public  Dignostic getById();
	
}
