package com.javatechie.spring.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javatechie.spring.entities.Dignostic;
import com.javatechie.spring.repository.DignosticRepo;
import com.javatechie.spring.service.IUIServices;

@Service
public class UIServicesImpl implements IUIServices {

	@Autowired
	DignosticRepo dignosticRepo;
	
	@Override
	public List<Dignostic> getALLDignostics() {
		// TODO Auto-generated method stub
		return dignosticRepo.findAll();
	}

	@Override
	public Dignostic getById() {
		// TODO Auto-generated method stub
		return dignosticRepo.findById(1);
	}

	@Override
	public void addDignostic(Dignostic data) {
		// TODO Auto-generated method stub
		try {
			dignosticRepo.save(data);
		}catch(Exception ex) {
			
		}
	}

	

	
}
